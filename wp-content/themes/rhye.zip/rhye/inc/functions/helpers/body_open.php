<?php

/**
 * Backward compatibility for WP 5.1 and below
 */
if ( ! function_exists( 'wp_body_open' ) ) {
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
}
