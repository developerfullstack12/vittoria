<?php

/**
 * Contact Form 7: Don't Wrap Form Fields Into </p>
 */
add_filter( 'wpcf7_autop_or_not', '__return_false' );
