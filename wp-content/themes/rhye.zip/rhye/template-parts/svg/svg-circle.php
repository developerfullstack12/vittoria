<svg class="svg-circle" viewBox="0 0 60 60" width="60" height="60" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
	<circle class="circle" cx="30" cy="30" r="29" fill="none"></circle>
</svg>
