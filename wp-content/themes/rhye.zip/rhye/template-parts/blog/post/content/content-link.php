<?php

/**
 * Content Post Type: Link
 */

the_content();
