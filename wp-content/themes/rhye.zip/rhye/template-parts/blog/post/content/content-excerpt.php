<?php

/**
 * Content Post Type: Excerpt
 */

the_excerpt();
